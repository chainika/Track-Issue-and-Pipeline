import logging
from datetime import datetime, timedelta, date
from dateutil.relativedelta import relativedelta

from odoo import api, fields, models, tools, SUPERUSER_ID
from odoo.tools.translate import _
from odoo.tools import email_re, email_split
from odoo.exceptions import UserError, AccessError

from odoo.addons.base.res.res_partner import FormatAddress
class ProjectIssue(models.Model):
    _inherit = "project.issue"
    opportunity_id=fields.Many2one('crm.lead',string='Opportunity')
  
