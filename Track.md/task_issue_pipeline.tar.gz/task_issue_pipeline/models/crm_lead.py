import logging
from datetime import datetime, timedelta, date
from dateutil.relativedelta import relativedelta

from odoo import api, fields, models, tools, SUPERUSER_ID
from odoo.tools.translate import _
from odoo.tools import email_re, email_split
from odoo.exceptions import UserError, AccessError

from odoo.addons.base.res.res_partner import FormatAddress
class Lead(FormatAddress, models.Model):
    _inherit = 'crm.lead'
    
    @api.multi
    def _activities_count(self):
        activity_data = self.env['crm.activity.report'].read_group([('lead_id', 'in', self.ids)], ['lead_id'], ['lead_id'])
        mapped_data = {act['lead_id'][0]: act['lead_id_count'] for act in activity_data}
        for val in self:
            val.activities_count = mapped_data.get(val.id, 0)

    @api.multi
    def _issues_count(self):
        Issue = self.env['project.issue']
        for partner in self:
            partner.issues_count = Issue.search_count([('opportunity_id', '=', partner.id)])

    @api.multi
    def _tasks_count(self):
        for val in self:
            val.tasks_count = len(val.task_ids)
    
    
    
    activities_count= fields.Integer(compute='_activities_count',string='# Activities')
    issues_count= fields.Integer(compute='_issues_count', string='# Issues')
    tasks_count= fields.Integer(compute='_tasks_count', string='# Tasks')
    task_ids = fields.One2many('project.task', 'opportunity_id', string='Tasks')
    issue_ids = fields.One2many('project.issue', 'opportunity_id', string='Issues')
