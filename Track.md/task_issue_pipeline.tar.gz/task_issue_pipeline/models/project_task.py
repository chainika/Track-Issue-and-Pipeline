from lxml import etree

from odoo import api, fields, models, tools, SUPERUSER_ID, _
from odoo.exceptions import UserError, ValidationError
from odoo.tools.safe_eval import safe_eval
class Task(models.Model):
    _inherit = 'project.task'
    
    opportunity_id=fields.Many2one('crm.lead',string='Opportunity')
    
    
    